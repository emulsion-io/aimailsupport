import { ProviderFactory } from './llmProviders/providerFactory'
import { getConfig, getConfigs, getCurrentMessageContent, getLanguageNameFromCode, isComposeDisplayed, logMessage, sendMessageToTab } from './helpers/utils'

import { RequestCoordinator } from './helpers/requestCoordinator'

const requests = new RequestCoordinator(sendMessageToTab)

// The array contains references to the menus of any custom languages selected
// by the user for which a translation is requested.
let translationMenuItemIds: (number | string)[] = null
let customPromptMenuItemIds: (number | string)[] = null

const menuIdCheckErrors = messenger.menus.create({ id: 'aiCheckErrors',
    title: browser.i18n.getMessage('mailCheckErrors'), contexts: ['compose_action_menu', 'selection'] })

// Create the menu entries -->
const menuIdAnalyzeIntent = messenger.menus.create({
    id: 'aiAnalyzeIntent',
    title: browser.i18n.getMessage('mailAnalyzeIntent'),
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdExplain = messenger.menus.create({
    id: 'aiExplain',
    title: browser.i18n.getMessage('mailExplain'),
    contexts: [
        'compose_action_menu',
        'message_display_action_menu',
        'selection'
    ]
})

const menuIdSummarize = messenger.menus.create({
    id: 'aiSummarize',
    title: browser.i18n.getMessage('mailSummarize'),
    contexts: [
        'compose_action_menu',
        'message_display_action_menu',
        'selection'
    ]
})

// Rephrase submenu -->
const subMenuIdRephrase = messenger.menus.create({
    id: 'aiSubMenuRephrase',
    title: browser.i18n.getMessage('mailRephrase'),
    contexts: [
        'selection'
    ]
})

const menuIdRephraseStandard = messenger.menus.create({
    id: 'aiRephraseStandard',
    title: browser.i18n.getMessage('mailRephrase.standard'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephraseFluid = messenger.menus.create({
    id: 'aiRephraseFluid',
    title: browser.i18n.getMessage('mailRephrase.fluid'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephraseCreative = messenger.menus.create({
    id: 'aiRephraseCreative',
    title: browser.i18n.getMessage('mailRephrase.creative'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephraseSimple = messenger.menus.create({
    id: 'aiRephraseSimple',
    title: browser.i18n.getMessage('mailRephrase.simple'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephraseFormal = messenger.menus.create({
    id: 'aiRephraseFormal',
    title: browser.i18n.getMessage('mailRephrase.formal'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephraseAcademic = messenger.menus.create({
    id: 'aiRephraseAcademic',
    title: browser.i18n.getMessage('mailRephrase.academic'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephraseExpanded = messenger.menus.create({
    id: 'aiRephraseExpanded',
    title: browser.i18n.getMessage('mailRephrase.expanded'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephraseShortened = messenger.menus.create({
    id: 'aiRephraseShortened',
    title: browser.i18n.getMessage('mailRephrase.shortened'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephrasePolite = messenger.menus.create({
    id: 'aiRephrasePolite',
    title: browser.i18n.getMessage('mailRephrase.polite'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephraseSeparator = messenger.menus.create({
    id: 'aiRephraseSeparator',
    type: 'separator',
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})

const menuIdRephraseSummarizeKeyPoints = messenger.menus.create({
    id: 'aiRephraseSummarizeKeyPoints',
    title: browser.i18n.getMessage('mailSummarizeKeyPoints'),
    parentId: subMenuIdRephrase,
    contexts: [
        'selection'
    ]
})
// <-- rephrase submenu

// Suggest reply submenu -->
const subMenuIdSuggestReply = messenger.menus.create({
    id: 'aiSubMenuSuggestReply',
    title: browser.i18n.getMessage('mailSuggestReply'),
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplyStandard = messenger.menus.create({
    id: 'aiSuggestReplyStandard',
    title: browser.i18n.getMessage('mailSuggestReply.standard'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplyFluid = messenger.menus.create({
    id: 'aiSuggestReplyFluid',
    title: browser.i18n.getMessage('mailSuggestReply.fluid'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplyCreative = messenger.menus.create({
    id: 'aiSuggestReplyCreative',
    title: browser.i18n.getMessage('mailSuggestReply.creative'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplySimple = messenger.menus.create({
    id: 'aiSuggestReplySimple',
    title: browser.i18n.getMessage('mailSuggestReply.simple'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplyFormal = messenger.menus.create({
    id: 'aiSuggestReplyFormal',
    title: browser.i18n.getMessage('mailSuggestReply.formal'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplyAcademic = messenger.menus.create({
    id: 'aiSuggestReplyAcademic',
    title: browser.i18n.getMessage('mailSuggestReply.academic'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplyExpanded = messenger.menus.create({
    id: 'aiSuggestReplyExpanded',
    title: browser.i18n.getMessage('mailSuggestReply.expanded'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplyShortened = messenger.menus.create({
    id: 'aiSuggestReplyShortened',
    title: browser.i18n.getMessage('mailSuggestReply.shortened'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplyPolite = messenger.menus.create({
    id: 'aiSuggestReplyPolite',
    title: browser.i18n.getMessage('mailSuggestReply.polite'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSuggestReplySeparator = messenger.menus.create({
    id: 'aiSuggestReplySeparator',
    type: 'separator',
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})

const menuIdSummarizeKeyPoints = messenger.menus.create({
    id: 'aiSummarizeKeyPoints',
    title: browser.i18n.getMessage('mailSummarizeKeyPoints'),
    parentId: subMenuIdSuggestReply,
    contexts: [
        'compose_action_menu'
    ]
})
// <-- suggest reply submenu

// Summarize submenu -->
const subMenuIdSummarize = messenger.menus.create({
    id: 'aiSubMenuSummarize',
    title: browser.i18n.getMessage('mailSummarizeAnd'),
    contexts: [
        'message_display_action_menu',
        'selection'
    ]
})

const menuIdSummarizeAndText2Speech = messenger.menus.create({
    id: 'aiSummarizeAndText2Speech',
    title: browser.i18n.getMessage('mailListen'),
    parentId: subMenuIdSummarize,
    contexts: [
        'message_display_action_menu',
        'selection'
    ]
})
// <-- summarize submenu

const menuIdText2Speech = messenger.menus.create({
    id: 'aiText2Speech',
    title: browser.i18n.getMessage('mailListen'),
    contexts: [
        'selection'
    ]
})

const menuIdTranslate = messenger.menus.create({
    id: 'aiTranslate',
    title: browser.i18n.getMessage('mailTranslate'),
    contexts: [
        'message_display_action_menu',
        'selection'
    ]
})

// Translate submenu -->
const subMenuIdTranslateAnd = messenger.menus.create({
    id: 'aiSubMenuTranslate',
    title: browser.i18n.getMessage('mailTranslateAnd'),
    contexts: [
        'message_display_action_menu',
        'selection'
    ]
})

const menuIdTranslateAndSummarize = messenger.menus.create({
    id: 'aiTranslateAndSummarize',
    title: browser.i18n.getMessage('mailSummarizeAndAfter'),
    parentId: subMenuIdTranslateAnd,
    contexts: [
        'message_display_action_menu',
        'selection'
    ]
})

const menuIdTranslateAndText2Speech = messenger.menus.create({
    id: 'aiTranslateAndText2Speech',
    title: browser.i18n.getMessage('mailListenAndAfter'),
    parentId: subMenuIdTranslateAnd,
    contexts: [
        'message_display_action_menu',
        'selection'
    ]
})

// Separator for the message display action menu
const menuIdTranslateSeparator = messenger.menus.create({
    id: "aiTranslateSeparator",
    type: 'separator',
    parentId: subMenuIdTranslateAnd,
    contexts: [
        'message_display_action_menu',
        'selection'
    ],
    visible: false
})

// Translations into the (optional) target languages selected by the user
updateMenuWithUserTranslationPreferences()
updateMenuWithUserCustomPromptPreferences()
// <-- translate submenu

const menuIdModerate = messenger.menus.create({
    id: 'aiModerate',
    title: browser.i18n.getMessage('mailModerate'),
    contexts: [
        'message_display_action_menu'
    ]
})

const menuIdSuggestImprovements = messenger.menus.create({
    id: 'aiSuggestImprovements',
    title: browser.i18n.getMessage('mailSuggestImprovements'),
    contexts: [
        'compose_action_menu',
        'message_display_action_menu',
        'selection'
    ]
})

const menuIdCustomPrompt = messenger.menus.create({
    id: 'aiCustomPrompt',
    title: browser.i18n.getMessage('mailCustomPrompt'),
    contexts: [
        'compose_action_menu',
        'message_display_action_menu'
    ]
})

const menuIdAutoTags = messenger.menus.create({
    id: 'aiAutoTags',
    title: browser.i18n.getMessage('mailAutoTags'),
    contexts: [
        'compose_action_menu',
        'message_display_action_menu'
    ]
})

const subMenuIdCustomPrompts = messenger.menus.create({
    id: 'aiSubMenuCustomPrompts',
    title: browser.i18n.getMessage('mailCustomPrompts'),
    contexts: [
        'compose_action_menu',
        'message_display_action_menu'
    ],
    visible: false
})

// Separator for the message display action menu
messenger.menus.create({
    id: 'aiMessageDisplayActionMenuSeparator1',
    type: 'separator',
    contexts: [
        'message_display_action_menu'
    ]
})

const menuIdOptions = messenger.menus.create({
    id: 'aiOptions',
    title: browser.i18n.getMessage('options'),
    contexts: [
        'message_display_action_menu'
    ]
})

// Invocation of the method to handle the visibility of menu options based on the
// user-selected LLM.
// This ensures that all menu items are properly handled at add-on startup.
updateMenuVisibility()
// <-- create the menu entries

// Register a listener for the menus.onClicked events
messenger.menus.onClicked.addListener(async (info: messenger.menus.OnClickData, tab: messenger.tabs.Tab) => {
    const tabId = tab.id

    // Handling scenarios that do not require LLM processing -->
    if([menuIdOptions, menuIdCustomPrompt].includes(info.menuItemId)) {
        if(info.menuItemId == menuIdOptions) {
            browser.runtime.openOptionsPage()
        }
        else if(info.menuItemId == menuIdCustomPrompt) {
            sendMessageToTab(tabId, {showPromptDisplay: true})
        }

        return
    }
    // <-- handling scenarios that do not require LLM processing

    const request = requests.begin(tabId)
    try {
        const configs = await getConfigs()
        const llmProvider = ProviderFactory.getInstance(configs)
        request.attach(llmProvider)

        // Retrieving text for LLM processing regardless of the user-requested option,
        // with the application of the general "thinking" output.
        request.send({ type: 'thinking', content: messenger.i18n.getMessage('thinking') })
        const textToBeProcessed = info.selectionText ?? await getCurrentMessageContent(tabId)

        if (textToBeProcessed == null) {
            request.send({ type: 'showError', content: messenger.i18n.getMessage('errorTextNotFound') })
            return
        }

        // Determine if we're in compose mode and notify the content script first
        const isCompose = await isComposeDisplayed(tabId)
        request.send({ type: 'setComposeMode', isCompose: isCompose })

        if(info.menuItemId == menuIdCheckErrors) {
            await request.runText(onChunk => llmProvider.checkTextForErrors(textToBeProcessed, onChunk))
        }
        else if(info.menuItemId == menuIdAnalyzeIntent) {
            await request.runText(onChunk => llmProvider.analyzeTextIntent(textToBeProcessed, onChunk))
        }
        else if(info.menuItemId == menuIdExplain) {
            await request.runText(onChunk => llmProvider.explainText(textToBeProcessed, onChunk))
        }
        else if(info.menuItemId == menuIdSummarize) {
            await request.runText(onChunk => llmProvider.summarizeText(textToBeProcessed, onChunk))
        }
        else if([menuIdRephraseStandard, menuIdRephraseFluid, menuIdRephraseCreative, menuIdRephraseSimple,
                menuIdRephraseFormal, menuIdRephraseAcademic, menuIdRephraseExpanded, menuIdRephraseShortened,
                menuIdRephrasePolite].includes(info.menuItemId)) {
            // Extracts the tone of voice from the menuItemId by taking a substring
            // starting from the 10th character.
            // The value 10 corresponds to the length of the string 'aiRephrase',
            // allowing the code to retrieve the portion of the menuItemId that
            // follows 'aiRephrase'.
            const toneOfVoice = (info.menuItemId as string).substring(10).toLowerCase()

            await request.runText(onChunk => llmProvider.rephraseText(textToBeProcessed, toneOfVoice, onChunk))
        }
        else if(info.menuItemId == menuIdRephraseSummarizeKeyPoints) {
            await llmProvider.summarizeDraftKeyPoints(textToBeProcessed).then((summaryAsBullets: string) => {
                request.send({ type: 'insertTextBelowSelection', content: summaryAsBullets })
                request.send({ type: 'hideOutput', content: '' })
            }).catch(error => {
                request.send({type: 'showError', content: errorMessage(error)})
                logMessage(`Error during key points summarization from selection: ${error.message}`, 'error')
            })
        }
        else if([menuIdSuggestReplyStandard, menuIdSuggestReplyFluid, menuIdSuggestReplyCreative, menuIdSuggestReplySimple,
                menuIdSuggestReplyFormal, menuIdSuggestReplyAcademic, menuIdSuggestReplyExpanded, menuIdSuggestReplyShortened,
                menuIdSuggestReplyPolite].includes(info.menuItemId)) {
            // Extracts the tone of voice from the menuItemId by taking a substring
            // starting from the 14th character.
            // The value 14 corresponds to the length of the string 'aiSuggestReply',
            // allowing the code to retrieve the portion of the menuItemId that
            // follows 'aiRephrase'.
            const toneOfVoice = (info.menuItemId as string).substring(14).toLowerCase()

            await request.runText(onChunk => llmProvider.suggestReplyFromText(textToBeProcessed, toneOfVoice, onChunk))
        }
        else if(info.menuItemId == menuIdSummarizeKeyPoints) {
            await llmProvider.summarizeDraftKeyPoints(textToBeProcessed).then((summaryAsBullets: string) => {
                request.send({ type: 'insertTextAtCursor', content: summaryAsBullets })
                request.send({ type: 'hideOutput', content: '' })
            }).catch(error => {
                request.send({type: 'showError', content: errorMessage(error)})
                logMessage(`Error during key points summarization: ${error.message}`, 'error')
            })
        }
        else if(info.menuItemId == menuIdSummarizeAndText2Speech) {
            try {
                const textSummarized = await llmProvider.summarizeText(textToBeProcessed)
                const blob = await llmProvider.getSpeechFromText(textSummarized)

                request.send({type: 'addAudio', content: blob})
            } catch (error) {
                request.send({type: 'showError', content: errorMessage(error)})
                logMessage(`Error during summarization and text-to-speech: ${error.message}`, 'error')
            }
        }
        else if(info.menuItemId == menuIdText2Speech) {
            await llmProvider.getSpeechFromText(textToBeProcessed).then(blob => {
                request.send({type: 'addAudio', content: blob})
            }).catch(error => {
                request.send({type: 'showError', content: errorMessage(error)})
                logMessage(`Error during text-to-speech conversion: ${error.message}`, 'error')
            })
        }
        else if(info.menuItemId == menuIdTranslate || translationMenuItemIds?.includes(info.menuItemId)) {
            let languageCode = null

            // The language code is retrieved when selected from a menu item that
            // propagates the specific code in its ID.
            const prefix = 'aiTranslateTo_'
            if ((info.menuItemId as string).startsWith(prefix)) {
                languageCode = (info.menuItemId as string).slice(prefix.length)
            }

            await request.runText(onChunk => llmProvider.translateText(textToBeProcessed, languageCode, onChunk))
        }
        else if(info.menuItemId == menuIdTranslateAndSummarize) {
            await request.runText(async onChunk => llmProvider.summarizeText(await llmProvider.translateText(textToBeProcessed), onChunk))
        }
        else if(info.menuItemId == menuIdTranslateAndText2Speech) {
            try {
                const textTranslated = await llmProvider.translateText(textToBeProcessed)
                const blob = await llmProvider.getSpeechFromText(textTranslated)

                request.send({type: 'addAudio', content: blob})
            } catch (error) {
                request.send({type: 'showError', content: errorMessage(error)})
                logMessage(`Error during translation and text2Speech: ${error.message}`, 'error')
            }
        }
        else if(info.menuItemId == menuIdModerate) {
            await llmProvider.moderateText(textToBeProcessed).then(moderatedResponse => {
                request.send({type: 'addChart', content: moderatedResponse})
            }).catch(error => {
                request.send({type: 'showError', content: errorMessage(error)})
                logMessage(`Error during moderation: ${error.message}`, 'error')
            })
        }
        else if(info.menuItemId == menuIdSuggestImprovements) {
            await request.runText(onChunk => llmProvider.suggestImprovementsForText(textToBeProcessed, onChunk))
        }
        else if((info.menuItemId as string).startsWith('aiSavedCustomPrompt_')) {
            const promptIndex = Number.parseInt((info.menuItemId as string).replace('aiSavedCustomPrompt_', ''), 10)
            const customPrompts = await getConfig('customPrompts') || []
            const selectedCustomPrompt = customPrompts[promptIndex]

            if(!selectedCustomPrompt?.prompt) {
                request.send({type: 'showError', content: browser.i18n.getMessage('errorCustomPromptNotFound')})
                return
            }

            await request.runText(onChunk => llmProvider.applyCustomPrompt(selectedCustomPrompt.prompt, textToBeProcessed, onChunk))
        }
        else if(info.menuItemId == menuIdAutoTags) {
            try {
                const displayedMessage = await messenger.messageDisplay.getDisplayedMessage(tabId)

                if(!displayedMessage) {
                    request.send({type: 'showError', content: browser.i18n.getMessage('errorAutoTagsMessageNotAvailable')})
                    return
                }

                const availableTags = await messenger.messages.tags.list()

                if(!availableTags || availableTags.length === 0) {
                    request.send({type: 'showError', content: browser.i18n.getMessage('errorAutoTagsNoAvailableTags')})
                    return
                }

                const aiResponse = await llmProvider.suggestTagsForMessage(textToBeProcessed, availableTags)
                if (!request.isCurrent() || request.stopped) return
                const suggestedTagKeys = extractSuggestedTagKeys(aiResponse, availableTags)

                const mergedTags = Array.from(new Set([...(displayedMessage.tags || []), ...suggestedTagKeys]))

                await messenger.messages.update(displayedMessage.id, { tags: mergedTags })

                const tagsByKey = new Map(availableTags.map(tag => [tag.key, tag]))
                const suggestedTagsForDisplay = suggestedTagKeys
                    .map((tagKey: string) => {
                        const tag = tagsByKey.get(tagKey)
                        if(!tag || !tag.tag) {
                            return {
                                label: tagKey,
                                color: '#6b7280'
                            }
                        }

                        return {
                            label: tag.tag,
                            color: tag.color || '#6b7280'
                        }
                    })

                if(suggestedTagsForDisplay.length > 0) {
                    request.send({
                        type: 'addTagsSummary',
                        content: {
                            intro: browser.i18n.getMessage('autoTagsSuccessIntro') || "J'ai classé votre email dans :",
                            tags: suggestedTagsForDisplay
                        }
                    })
                }
                else {
                    request.send({
                        type: 'addText',
                        content: browser.i18n.getMessage('autoTagsSuccessMessage', [browser.i18n.getMessage('autoTagsNoTagApplied')])
                    })
                }
            } catch (error) {
                request.send({type: 'showError', content: errorMessage(error) || browser.i18n.getMessage('errorAutoTagsInvalidResponse')})
                logMessage(`Error during auto tags assignment: ${error.message}`, 'error')
            }
        }
        // Fallback message case, but only if the menu does not match any values to
        // ignore, e.g., options.
        else if (!['aiOptions'].includes(info.menuItemId as string)) {
            request.send({type: 'showError', content: `Invalid menu item selected: ${info.menuItemId}`})
            logMessage(`Invalid menu item selected: ${info.menuItemId}`, 'error')
        }
    } catch (error) {
        if (!request.stopped) await request.send({ type: 'showError', content: errorMessage(error) })
    } finally {
        if (request.stopped) await request.send({ type: 'endText' })
        request.finish()
    }
})

// Requests from the injected panels always use the sender's tab.
browser.runtime.onMessage.addListener(async (message, sender) => {
    const tabId = sender.tab?.id
    if (tabId === undefined) return
    if (message.type === 'stopGeneration') {
        requests.stop(tabId, message.discardOutput === true, message.requestId)
        return
    }
    if (message.type === 'insertAtComposeTop') {
        try {
            const compose = await messenger.compose.getComposeDetails(tabId)
            if (compose.isPlainText) await messenger.compose.setComposeDetails(tabId,
                { plainTextBody: `${message.textContent}\n\n${compose.plainTextBody || ''}` })
            else await messenger.compose.setComposeDetails(tabId,
                { body: `<div>${message.htmlContent}</div><br>${compose.body || ''}` })
        } catch (error) { logMessage(`Error inserting generated text: ${errorMessage(error)}`, 'error') }
        return
    }
    if (message.action !== 'sendUserPromptToBackground' && message.type !== 'refineLastResponse') return
    const request = requests.begin(tabId)
    try {
        const provider = ProviderFactory.getInstance(await getConfigs())
        request.attach(provider)
        const content = message.type === 'refineLastResponse' ? message.lastResponse : await getCurrentMessageContent(tabId)
        if (!content) throw new Error(messenger.i18n.getMessage('errorTextNotFound'))
        await request.send({ type: 'setComposeMode', isCompose: await isComposeDisplayed(tabId) })
        await request.send({ type: 'thinking', content: messenger.i18n.getMessage('thinking') })
        await request.runText(onChunk => provider.applyCustomPrompt(
            message.type === 'refineLastResponse' ? message.refinementPrompt : message.data.userPrompt, content, onChunk))
    } catch (error) {
        if (!request.stopped) await request.send({ type: 'showError', content: errorMessage(error) })
    } finally { request.finish() }
})
messenger.tabs.onRemoved.addListener(tabId => requests.stop(tabId, true))

function errorMessage(error: any): string {
    return error?.name === 'AbortError' ? messenger.i18n.getMessage('errorServiceTimeout') : error?.message || String(error)
}

/**
 * Using the messageDisplayScripts API for customizing the content displayed when
 * viewing a message.
 *
 * For more information check the docs at:
 * https://webextension-api.thunderbird.net/en/stable/messageDisplayScripts.html
 */
messenger.messageDisplayScripts.register({
    js: [
        { file: '/vendor/purify.min.js' },
        { file: '/outputDisplay/outputDisplay.js' },
        { file: '/promptDisplay/promptDisplay.js' }
    ],
    css: [
        { file: '/outputDisplay/outputDisplay.css' },
        { file: '/promptDisplay/promptDisplay.css' }
    ]
})

/**
 * Using the composeScripts API for customizing the content displayed when create
 * or edit a message.
 *
 * For more information check the docs at:
 * https://webextension-api.thunderbird.net/en/stable/composeScripts.html
 */
messenger.composeScripts.register({
    js: [
        { file: '/vendor/purify.min.js' },
        { file: '/outputDisplay/outputDisplay.js' },
        { file: '/promptDisplay/promptDisplay.js' }
    ],
    css: [
        { file: '/outputDisplay/outputDisplay.css' },
        { file: '/promptDisplay/promptDisplay.css' }
    ]
})

// Listens for the message signaling the change in configurations to update the
// interface.
browser.runtime.onMessage.addListener(async (message) => {
    if (message.type === 'optionsChanged') {
        updateMenuVisibility()
        updateMenuWithUserTranslationPreferences()
        updateMenuWithUserCustomPromptPreferences()
    }
})

// The function manages the visibility of menu options based on the user-selected
// LLM.
async function updateMenuVisibility(): Promise<void> {
    const configs = await getConfigs()
    const llmProvider = ProviderFactory.getInstance(configs)

    messenger.menus.update(menuIdCheckErrors, { enabled: llmProvider.canCheckTextForErrors() })

    // canAnalyzeTextIntent -->
    messenger.menus.update(menuIdAnalyzeIntent, {
        enabled: llmProvider.canAnalyzeTextIntent()
    })
    // <-- canAnalyzeTextIntent

    // canApplyCustomPrompt -->
    messenger.menus.update(menuIdCustomPrompt, {
        enabled: llmProvider.canApplyCustomPrompt()
    })

    messenger.menus.update(menuIdAutoTags, {
        enabled: llmProvider.canApplyCustomPrompt()
    })

    messenger.menus.update(subMenuIdCustomPrompts, {
        enabled: llmProvider.canApplyCustomPrompt()
    })
    // <-- canApplyCustomPrompt

    // canExplainText -->
    messenger.menus.update(menuIdExplain, {
        enabled: llmProvider.canExplainText()
    })
    // <-- canExplainText

    // canModerateText -->
    messenger.menus.update(menuIdModerate, {
        enabled: llmProvider.canModerateText()
    })
    // <-- canModerateText

    // canRephraseText -->
    messenger.menus.update(subMenuIdRephrase, {
        enabled: llmProvider.canRephraseText()
    })
    // <-- canRephraseText

    // canSpeechFromText -->
    messenger.menus.update(menuIdText2Speech, {
        enabled: llmProvider.canSpeechFromText()
    })

    messenger.menus.update(menuIdSummarizeAndText2Speech, {
        enabled: llmProvider.canSpeechFromText()
    })

    messenger.menus.update(menuIdTranslateAndText2Speech, {
        enabled: llmProvider.canSpeechFromText()
    })
    // <-- canSpeechFromText

    // canSuggestImprovementsForText -->
    messenger.menus.update(menuIdSuggestImprovements, {
        enabled: llmProvider.canSuggestImprovementsForText()
    })
    // <-- canSuggestImprovementsForText

    // canSuggestReply -->
    messenger.menus.update(subMenuIdSuggestReply, {
        enabled: llmProvider.canSuggestReply()
    })
    // <-- canSuggestReply

    // canSummarizeText -->
    messenger.menus.update(menuIdSummarize, {
        enabled: llmProvider.canSummarizeText()
    })

    messenger.menus.update(subMenuIdSummarize, {
        enabled: llmProvider.canSummarizeText()
    })
    // <-- canSummarizeText

    // canTranslateText -->
    messenger.menus.update(menuIdTranslate, {
        enabled: llmProvider.canTranslateText()
    })

    messenger.menus.update(subMenuIdTranslateAnd, {
        enabled: llmProvider.canTranslateText()
    })
    // <-- canTranslateText
}

// Updates the menu based on the user's preferred languages.
// This function retrieves the user's language preferences and dynamically
// updates the menu options accordingly.
async function updateMenuWithUserTranslationPreferences(): Promise<void> {
    const mainUserLanguageCode = await getConfig('mainUserLanguageCode')
    const translationLanguageCodes = await getConfig('translationLanguageCodes')

    // Removal of old menu items, necessary to ensure consistency of values
    // in case the user updates their language settings.
    translationMenuItemIds?.forEach((menuItemId: (number | string)) => {
        messenger.menus.remove(menuItemId)
    })

    // Inhibition of visibility for the separator between general translation
    // menu items and those specific to multiple languages.
    messenger.menus.update(menuIdTranslateSeparator, {
        visible: false
    })

    if(translationLanguageCodes?.length > 0) {
        translationMenuItemIds = []

        // Enabling the visibility of the separator between general translation
        // menu items and those specific to multiple languages.
        messenger.menus.update(menuIdTranslateSeparator, {
            visible: true
        })

        translationLanguageCodes.forEach((languageCode: string) => {
            const languageName = getLanguageNameFromCode(languageCode, mainUserLanguageCode)

            if(languageName !== undefined) {
                // The language code is embedded directly into the menu item ID to uniquely
                // identify the translation target (e.g., "aiTranslateTo_it" for Italian).
                // This allows easy lookup or removal of specific language-related menu items.
                const menuId = `aiTranslateTo_${languageCode}`

                const menuItemId = messenger.menus.create({
                    id: menuId,
                    title: browser.i18n.getMessage('mailTranslateTo', languageName),
                    parentId: subMenuIdTranslateAnd,
                    contexts: [
                        'message_display_action_menu',
                        'selection'
                    ]
                })

                translationMenuItemIds.push(menuItemId)
            }
        })
    }
}

// Updates the menu based on the user's preferred custom prompts.
// This function retrieves the user's custom prompts and dynamically
// updates the submenu options accordingly.
async function updateMenuWithUserCustomPromptPreferences(): Promise<void> {
    const customPrompts = await getConfig('customPrompts')

    // Remove old menu items to keep consistency after options update.
    customPromptMenuItemIds?.forEach((menuItemId: (number | string)) => {
        messenger.menus.remove(menuItemId)
    })

    customPromptMenuItemIds = []

    messenger.menus.update(subMenuIdCustomPrompts, {
        visible: false
    })

    if(customPrompts?.length > 0) {
        messenger.menus.update(subMenuIdCustomPrompts, {
            visible: true
        })

        customPrompts.forEach((customPrompt: { title: string }, index: number) => {
            const menuId = `aiSavedCustomPrompt_${index}`

            const menuItemId = messenger.menus.create({
                id: menuId,
                title: customPrompt.title,
                parentId: subMenuIdCustomPrompts,
                contexts: [
                    'compose_action_menu',
                    'message_display_action_menu'
                ]
            })

            customPromptMenuItemIds.push(menuItemId)
        })
    }
}

function extractSuggestedTagKeys(rawResponse: string, availableTags: { key: string; tag: string; color: string; ordinal: string }[]): string[] {
    const sanitizedResponse = rawResponse
        .replace(/^```json\s*/i, '')
        .replace(/^```\s*/i, '')
        .replace(/\s*```$/i, '')
        .trim()

    const allowedTagKeys = availableTags.map((tag) => tag.key)
    const allowedTagKeysSet = new Set(allowedTagKeys)
    const normalizedKeyToKey = new Map<string, string>()
    const normalizedLabelToKey = new Map<string, string>()

    availableTags.forEach((tag) => {
        const normalizedKey = normalizeComparableTagText(tag.key)
        if(normalizedKey && !normalizedKeyToKey.has(normalizedKey)) {
            normalizedKeyToKey.set(normalizedKey, tag.key)
        }

        const normalizedLabel = normalizeComparableTagText(tag.tag)
        if(normalizedLabel && !normalizedLabelToKey.has(normalizedLabel)) {
            normalizedLabelToKey.set(normalizedLabel, tag.key)
        }
    })

    let parsedResponse: { tags?: unknown }

    try {
        parsedResponse = parseAutoTagsResponse(sanitizedResponse)
    } catch {
        throw new Error(browser.i18n.getMessage('errorAutoTagsInvalidResponse'))
    }

    if (!Array.isArray(parsedResponse?.tags)) {
        throw new Error(browser.i18n.getMessage('errorAutoTagsInvalidResponse'))
    }

    return parsedResponse.tags
        .filter((tag): tag is string => typeof tag === 'string')
        .map((tag) => normalizeSuggestedTagKey(tag))
        .map((tag) => {
            if(allowedTagKeysSet.has(tag)) {
                return tag
            }

            const normalizedTag = normalizeComparableTagText(tag)
            if(!normalizedTag) {
                return ''
            }

            return normalizedKeyToKey.get(normalizedTag) || normalizedLabelToKey.get(normalizedTag) || ''
        })
        .filter((tag) => tag.length > 0)
        .filter((tag, index, tags) => tags.indexOf(tag) === index)
        .slice(0, 4)
}

function parseAutoTagsResponse(responseText: string): { tags?: unknown } {
    let candidate = responseText.trim()

    for(let index = 0; index < 3; index += 1) {
        const parsedCandidate = JSON.parse(candidate)

        if(typeof parsedCandidate === 'string') {
            candidate = parsedCandidate.trim()
            continue
        }

        if(parsedCandidate !== null && typeof parsedCandidate === 'object') {
            return parsedCandidate as { tags?: unknown }
        }

        break
    }

    throw new Error(browser.i18n.getMessage('errorAutoTagsInvalidResponse'))
}

function normalizeSuggestedTagKey(tag: string): string {
    return tag
        .trim()
        .replace(/^['"]+|['"]+$/g, '')
        .replace(/\\(["'])/g, '$1')
        .trim()
}

function normalizeComparableTagText(input: string): string {
    return normalizeSuggestedTagKey(input)
    .replace(/[\u0000-\u001F\u007F-\u009F]/g, '-')
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
    .replace(/[‐‑‒–—―−]/g, '-')
    .replace(/[^\p{L}\p{N}$_-]+/gu, '-')
    .replace(/-+/g, '-')
    .replace(/_+/g, '_')
        .replace(/\s+/g, ' ')
        .toLowerCase()
        .trim()
}